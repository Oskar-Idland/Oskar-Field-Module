# Example Package

This package is made to be used in the calculations and plotting of electromagnetic fields and potentials. 
[Github-flavored Markdown](https://github.com/Oskar-Idland/FYS-1120/tree/main/ELMAG_Module)